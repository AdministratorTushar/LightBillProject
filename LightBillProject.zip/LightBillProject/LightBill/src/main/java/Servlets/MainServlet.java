package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Classes.AdminBeanClass;
import Classes.AllDataBeanClass;
import Classes.UpdateDetails;



@WebServlet(urlPatterns = {"/loginpage","/newconnection","/activate","/datafetch","/billpayment","/lastmassage"})

public class MainServlet extends HttpServlet {
	public static String u=null;
	public static String p=null;
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String url=req.getServletPath();
	
		
	if(url.equals("/loginpage"))
	{
		loginpage(req,resp);
		
	}
	
	 if(url.equals("/newconnection"))
	{
		addnewConnection(req,resp);
		
	}
	 if(url.equals("/activate"))
	 {
		 activateaccount(resp,req);
	 }
	 if(url.equals("/datafetch"))
	 {
		  alldatafetch(req, resp);
	 }
	 if(url.equals("/billpayment"))
	 {
		 paybill(req,resp);
		 
	 }
	 if(url.equals("/lastmassage"))
			 {
		 
		 updatebill(req,resp); 
			 }
			 
	}
	
	

	

	private void loginpage(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		String username=req.getParameter("username1");
		String password=req.getParameter("password1");
		AdminBeanClass a1=new AdminBeanClass();
		a1.setUsername(username);
		a1.setPassword(password);
		UpdateDetails u1=new UpdateDetails();
		AdminBeanClass data=u1.checkAdminOrUser(a1);
		String user=data.getUsername();
		String pass=data.getPassword();
		
		
	
		
		if(username.equals("q") && password.equals("q"))
		{
		
		RequestDispatcher rd=req.getRequestDispatcher("newconnection.html");
		rd.forward(req, resp);
		 
		}
	
		
		 if(username.equalsIgnoreCase(user) && password.equalsIgnoreCase(pass))
		{
			 {
			 u=user;
			 p=pass;
			 }
			 
			UpdateDetails d1=new UpdateDetails();
			
			req.setAttribute("data1", user);
			req.setAttribute("data2", pass);
			RequestDispatcher rd=req.getRequestDispatcher("useroption.jsp");
			rd.forward(req, resp);
		}
		
		  else
		 {
			 resp.sendRedirect("index.html");
		 }	
	}
	
	
	
	
	
	
	
	
	
	private void addnewConnection(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		int customerId=Integer.parseInt(req.getParameter("customer_id"));
		String name=req.getParameter("customer_name");
		String mobileNumber=req.getParameter("mobilenumber");
		String Address=req.getParameter("address");
		AdminBeanClass u1=new  AdminBeanClass();
		u1.setCustomerId(customerId);
		u1.setCustomerName(name);
		u1.setContactNumber(mobileNumber);
		u1.setAddress(Address);
		UpdateDetails d1=new UpdateDetails();
		int count=d1.updateDetails(u1);
		PrintWriter pw=resp.getWriter();
		if(count>0)
		{
			resp.sendRedirect("newconnection.html");
			pw.print("<h1 style=color:green>"+"Connection Added Successfuly"+"</h1>");
			
		}
		else
		{
			pw.print("<h1 style=color:red>"+"Somthing went wrong"+"</h1>");
		}
	
		
	}
	
	
	
	
	
	
	private void activateaccount(HttpServletResponse resp, HttpServletRequest req) throws IOException, ServletException {
		String user=req.getParameter("username2");
		String pass=req.getParameter("password2");
		String number=req.getParameter("number2");
		AdminBeanClass a1=new AdminBeanClass();
		a1.setUsername(user);
		a1.setPassword(pass);
		a1.setContactNumber(number);
		UpdateDetails u1=new UpdateDetails();
		PrintWriter pw=resp.getWriter();
		int count=u1.activateId(a1);
		if(count>0)
		{
		req.setAttribute("count", count);
		RequestDispatcher rd=req.getRequestDispatcher("index.html");
		rd.forward(req, resp);
		}
		else 
		{
			pw.print("<h1 style=color:red>"+"Somthing Went Wrong"+"</h1>");
			
			
		}
		
		}
		

	

	
	
	
	


	private void alldatafetch(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		
			String username=u;
			String password=p;
		AllDataBeanClass a1=new AllDataBeanClass();
		a1.setUsername(username);
		a1.setPassword(password);
		UpdateDetails u1=new UpdateDetails();
		ArrayList<AllDataBeanClass> data=u1.displayalldata(a1);
		
		req.setAttribute("data", data);
		RequestDispatcher rd=req.getRequestDispatcher("finaldata.jsp");
		rd.forward(req, resp);
	
		}

	

	
	
	


	private void paybill(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		int meterId=Integer.parseInt(req.getParameter("meterid1"));
		String number=req.getParameter("mobilenumber1");	
		double money=Double.parseDouble(req.getParameter("money1"));
		
	
		String username=u;
		String password=p;
		
		PrintWriter pw=resp.getWriter();
		
		AllDataBeanClass d1=new AllDataBeanClass();
		
		d1.setUsername(username);
		d1.setPassword(password);
		d1.setNumber(number);
		d1.setMeterId(meterId);
		d1.setMoney(money);
		
		UpdateDetails d2=new UpdateDetails();
		int d=d2.payBill(d1);
		if(d>0)
		{
	   
		   pw.print("<h1 style=color:green>"+"Payment Done...!"+"</h1>");
		}else
		{
	 
		   pw.print("<h1 style=color:red>"+"something went wrong"+"</h1>");
		}
	   
	   
	   
		
		
	}
	
	
	
	
	
	

	private void updatebill(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		ArrayList<AllDataBeanClass> data=alldata(req, resp);
		int meterId=0;
		for(AllDataBeanClass d:data)
		{
			meterId=d.getMeterId();
		}
		AllDataBeanClass d1=new AllDataBeanClass();
		d1.setMeterId(meterId);
		UpdateDetails d2=new UpdateDetails();
		boolean status=d2.updatedata(d1);
		req.setAttribute("status", status);
		RequestDispatcher rd=req.getRequestDispatcher("conform.jsp");
		rd.forward(req, resp);
		
	}



	
	
	
	
	
private ArrayList<AllDataBeanClass> alldata(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		
		
		ArrayList<AllDataBeanClass> data = null;
		HttpSession ses2=req.getSession(true);
		String username=(String) ses2.getAttribute("data1");
		String password=(String ) ses2.getAttribute("data2");
		AllDataBeanClass a1=new AllDataBeanClass();
		a1.setUsername(username);
		a1.setPassword(password);
		UpdateDetails u1=new UpdateDetails();
	    data=u1.displayalldata(a1);
		
		return data;	
	}


	

}
