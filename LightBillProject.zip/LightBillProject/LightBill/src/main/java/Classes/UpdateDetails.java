package Classes;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class UpdateDetails{
	static Connection con;
	static
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/lightbillproject","root","root");

		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
	} 
	public int updateDetails(AdminBeanClass u1) {
		PreparedStatement pstmt;
		int count=0;
		String querry="insert into customer_info (customer_id,customer_name,customer_mobile,customer_address) values(?,?,?,?)";
		try {
			pstmt=con.prepareStatement(querry);
			pstmt.setInt(1, u1.getCustomerId());
			pstmt.setString(2, u1.getCustomerName());
			pstmt.setString(3, u1.getContactNumber());
			pstmt.setString(4, u1.getAddress());
			 count =pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
		
		
	}
	
	public int activateId(AdminBeanClass a1) {

		ResultSet rs;
		Statement stmt;
		int count=0;
		String querry="select * from customer_info where customer_mobile='"+a1.getContactNumber()+"'" ;
		try {
			stmt= con.createStatement();
			rs=stmt.executeQuery(querry);
			while(rs.next())
			{
				String username=rs.getString(2);
				String password=rs.getString(3);
				String mobile=rs.getString(5);
				if(username==null && password==null && mobile!=null) {
					PreparedStatement pstmt;
					
					String  querry1="update customer_info set username=?,password=? where customer_mobile=?";
					try {
						pstmt=con.prepareStatement(querry1);
						pstmt.setString(1, a1.getUsername());
						pstmt.setString(2, a1.getPassword());
						pstmt.setString(3, a1.getContactNumber());
						count=pstmt.executeUpdate();
					
						
						
					} catch (SQLException e) {
					
						e.printStackTrace();
					}
					
					
				}
				
				
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return count;
		
	}

	

	public AdminBeanClass checkAdminOrUser(AdminBeanClass a1) {
		AdminBeanClass data=new AdminBeanClass();
      PreparedStatement pstmt;
		int count=0;
		ResultSet rs;
		String querry1="select * from customer_info where username=? and password=?";
		try {
			pstmt=con.prepareStatement(querry1);
			pstmt.setString(1, a1.getUsername());
			pstmt.setString(2, a1.getPassword());
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				String user=rs.getString(2);
				String pass=rs.getString(3);
				
				data.setUsername(user);
				data.setPassword(pass);
				
			}
			
		}
		catch(Exception e)
		{
			
		}
		return data;
		
	}
	
	
	
	public ArrayList<AllDataBeanClass> displayalldata(AllDataBeanClass a1) {
		ArrayList< AllDataBeanClass> data=new ArrayList<AllDataBeanClass>();
		PreparedStatement pstmt;
		

		ResultSet rs;
		
		String querry1= " SELECT * FROM customer_info FULL JOIN lightbill_details ON customer_id=lightbill_details WHERE username=? and password=?" ;
		try {
			pstmt=con.prepareStatement(querry1);
			pstmt.setString(1, a1.getUsername());
			pstmt.setString(2, a1.getPassword());
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				int CustomerId=rs.getInt(1);
				String user=rs.getString(2);
				String pass=rs.getString(3);
				String name=rs.getString(4);
				String number=rs.getString(5);
				String Address=rs.getString(6);
				
				int meterId=rs.getInt(7);	
				int curretReading=rs.getInt(8);
				double costPerUnit=rs.getDouble(9);
				double finalBill =rs.getDouble(10);
				Date fromDate=rs.getDate(11);
				Date todate=rs.getDate(12);
				
				
				a1.setCustomerId(CustomerId);
				a1.setUsername(user);
				a1.setPassword(pass);
				a1.setName(name);
				a1.setNumber(number);
				a1.setAddress(Address);
				
				a1.setMeterId(meterId);
			    a1.setCurrentReading(curretReading);
			    a1.setCostPerUnit(costPerUnit);
			    a1.setTotalBill(finalBill);
			    a1.setFromDate(fromDate);
			    a1.setToDate(todate);
	
			    
				data.add(a1);
			
					
				}
		}
		catch (Exception e) {
		
		}
		return data;
		
	}

	public int payBill(AllDataBeanClass a1) {
		
		PreparedStatement pstmt;
		int finalresult=0;

		ResultSet rs;
		
		String querry1= " SELECT * FROM customer_info FULL JOIN lightbill_details ON customer_id=lightbill_details WHERE username=? AND PASSWORD=?;" ;
		try {
			pstmt=con.prepareStatement(querry1);
			pstmt.setString(1, a1.getUsername());
			pstmt.setString(2, a1.getPassword());
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				int CustomerId=rs.getInt(1);
				String user=rs.getString(2);
				String pass=rs.getString(3);
				String name=rs.getString(4);
				String number=rs.getString(5);
				String Address=rs.getString(6);
				
				int meterId=rs.getInt(7);	
				int curretReading=rs.getInt(8);
				double costPerUnit=rs.getDouble(9);
				double finalBill =rs.getDouble(10);
				Date fromDate=rs.getDate(11);
				Date todate=rs.getDate(12);
				
				
			
				
				  if(user.equals(a1.getUsername()) && pass.equals(a1.getPassword()) )
				    {
				    	PreparedStatement stmt;
				    	String query="update lightbill_details set current_reading=? , total_bill=? where meter_id=?" ;
				    	stmt=con.prepareStatement(query);
				    	stmt.setInt(1, 0);
				    	stmt.setDouble(2,0);
				    	stmt.setInt(3, a1.getMeterId());
				    	finalresult=stmt.executeUpdate();
				
				
				    }
					
				}
		}
		catch (Exception e) {
		
		}
		
	return finalresult;
		
			
	}

	public boolean updatedata(AllDataBeanClass d1) {
		{
			boolean  status;
			PreparedStatement pstmt;
			String querry2="UPDATE lightbill_details SET total_bill=0,current_reading=0,from_date=0,to_date=0 WHERE meter_id=?";
			try {
				pstmt=con.prepareStatement(querry2);
				pstmt.setInt(1, d1.getMeterId());
				pstmt.executeUpdate();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
			
		}
		return true;
		
	}

	
		
	/*
	 *  */

}
