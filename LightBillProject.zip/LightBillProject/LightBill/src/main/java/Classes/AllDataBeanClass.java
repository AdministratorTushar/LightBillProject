package Classes;

import java.sql.Date;

public class AllDataBeanClass {
	private int CustomerId;
	private String Username;
	private String password;
	private String name;
	private String number;
	private String address;
	private int meterId;
	private double money;
	private int currentReading;
	private double costPerUnit;
	private double remainingBill;
	private double thisMonthBill;
	private double totalBill;
	private Date fromDate;
	private Date toDate;
	
	
	public AllDataBeanClass()
	{
		
	}
	

	public AllDataBeanClass(String username, String password, String number, int meterId, double money) {
		super();
		Username = username;
		this.password = password;
		this.number = number;
		this.meterId = meterId;
		this.money = money;
	}
	public int getCurrentReading() {
		return currentReading;
	}
	public void setCurrentReading(int currentReading) {
		this.currentReading = currentReading;
	}
	public double getCostPerUnit() {
		return costPerUnit;
	}
	public void setCostPerUnit(double costPerUnit) {
		this.costPerUnit = costPerUnit;
	}
	public double getRemainingBill() {
		return remainingBill;
	}
	public void setRemainingBill(double remainingBill) {
		this.remainingBill = remainingBill;
	}
	public double getThisMonthBill() {
		return thisMonthBill;
	}
	public void setThisMonthBill(double thisMonthBill) {
		this.thisMonthBill = thisMonthBill;
	}
	public double getTotalBill() {
		return totalBill;
	}
	public void setTotalBill(double totalBill) {
		this.totalBill = totalBill;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public int getMeterId() {
		return meterId;
	}
	public void setMeterId(int meterId) {
		this.meterId = meterId;
	}
	public int getCustomerId() {
		return CustomerId;
	}
	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	

}
